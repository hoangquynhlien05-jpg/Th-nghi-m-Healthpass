# HealthPass — Personal BA Portfolio Case Study (v2)

Static single-file HTML site ready for Vercel.

## Changes in v2
- Removed the Emergency Doctor interview profile.
- Five participant profiles: three patient-side and two medical-side.
- Click interview/persona images to open the full interview board in a modal.
- Reworked user-group and persona presentation.
- Updated research section titles and synthesis language.

## Deploy
Import the folder into Vercel using Framework Preset: Other. No build command is required.
